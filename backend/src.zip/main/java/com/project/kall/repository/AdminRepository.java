//package com.project.kall.repository;
//
//import com.project.kall.entity.AdminEntity;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//
//import java.util.Optional;
//
//public interface AdminRepository extends JpaRepository<AdminEntity, String> {
//    Optional<AdminEntity> findById(String userId);
//}
