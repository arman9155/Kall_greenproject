package user;

import static org.junit.jupiter.api.Assertions.*;

class UserApplicationTest {

}

