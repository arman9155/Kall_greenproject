package com.project.kall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KallApplicationTests {

	@Test
	void contextLoads() {
	}

}
